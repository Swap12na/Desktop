package com.example.flutterconversionapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
